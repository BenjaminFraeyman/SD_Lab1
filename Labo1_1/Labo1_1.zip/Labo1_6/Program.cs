﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo1_6
{
    class MeetkundigeRij
    {
        static void Main(string[] args)
        {
            Console.WriteLine("geef eerste element op");
            int eerste = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("geef reden");
            int reden = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("geef het aantal elementen op");
            int aantal = Convert.ToInt32(Console.ReadLine());

            Boolean laatste = true;
            if (aantal == 0)
                {
                    Console.WriteLine("ERROR ERROR ERROR ERROR ERROR ERROR"); // ANDERS LOOP DIE HEEL DE TIJD 1 AFPRINT
                    Console.WriteLine("AANTAL MAG NIET 0 ZIJN");
                    laatste = false;
                }

            if (aantal == 1)
                {
                    Console.WriteLine(eerste); // anders toch 2 elementen              
                    laatste = false;
                }

            else
                {
                    Console.WriteLine(eerste);
                }

            int count = 0;
            while (laatste)
            {
                if (eerste > (int.MaxValue / reden)) // indien waarde te groot is
                {
                    Console.WriteLine("ERROR ERROR ERROR ERROR ERROR ERROR");
                    Console.WriteLine("Output te groot");
                    laatste = false;
                    Console.ReadLine();
                }

                int volgende;
                volgende = eerste * reden; // vermenigvuldiging               
                Console.WriteLine(volgende);
                
                eerste = volgende;
                count++;

                if (count == aantal) // laatste element
                    {
                        laatste = false;
                    }                                     
            }
            Console.ReadLine();
        }
    }
}

// BENODIGDE TIJD
// 1h30