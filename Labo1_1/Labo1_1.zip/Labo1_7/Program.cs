﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo1_7
{
    class Huizen
    {
        static void Main(string[] args)
        {
            // STARTWAARDES AANMAKEN
            int Min = 0;
            int Max = 2; // hierdoor min = 0 en max = 1
            int[] huizen = new int[20]; // aantal huizen
            Random random = new Random(DateTime.Now.Millisecond); //random generator oproepen en gebonden aan de tijd > iedere keer andere input

            for (int i = 0; i < huizen.Length; i++)
                {
                    huizen[i] = random.Next(Min, Max);
                }
            
            // VOLGENDE JAREN 
            int jaar = 0;   
            while (jaar < 24) // gedurende de 24 jaar
                {               
                    int[] huizen2 = Nieuw(huizen); // nieuwe situatie
              
                    // 0 EN 1 NAAR 2*BLANCO EN 2*X KRIJGEN
                    string[] huizen3 = Omzetting(huizen2);               
                    foreach (var item in huizen3)
                        {
                            Console.Write(item + " " );
                        }

                    huizen = huizen2;
                    jaar++; // volgend jaar

                    Console.WriteLine();
                }           
            Console.ReadLine();            
        }

        // METHODE OM NIEWE RIJ TE MAKEN VOOR VOLGENDE JAAR
        static int[] Nieuw(int[] huizen)
            {
                int[] huizen2 = new int[20];

                // SPECIAAL GEVAL VOOR HUIS 1 (EERSTE)
                if (huizen[1] == 1)
                    {
                        huizen2[0] = 1;
                    }
                if (huizen[1] == 0)
                    {
                        huizen2[0] = 0;
                    }

                // SPECIAAL GEVAL VOOR HUIS 20 (LAATSTE)
                if (huizen[18] == 1)
                    {
                        huizen2[19] = 1;
                    }
                if (huizen[18] == 0)
                    {
                        huizen2[19] = 0;
                    }
           
                // BEREKENING INHOUD VAN HUIZEN 2-19
                for (int i = 1; i < huizen.Length - 1; i++)
                    {
                        if (huizen[i] == 1) //bewoont
                            {
                                if (huizen[i - 1] == 1 && huizen[i + 1] == 0) // links bewoont en rechts leeg
                                    {
                                        huizen2[i] = 1;
                                    }
                                if (huizen[i - 1] == 0 && huizen[i + 1] == 1) // links leeg en rechts bewoont
                    {
                                        huizen2[i] = 1;
                                    }

                                if (huizen[i - 1] == 1 && huizen[i + 1] == 1) // links bewoont en rechts bewoont
                    {
                                        huizen2[i] = 0;
                                    }
                                if (huizen[i - 1] == 0 && huizen[i + 1] == 0) // links leeg en rechts leeg
                    {
                                        huizen2[i] = 0;
                                    }                  
                            }
                        if (huizen[i] == 0) // niet bewoont
                            {
                                if (huizen[i - 1] == 1 && huizen[i + 1] == 1)
                                    {
                                        huizen2[i] = 1;
                                    }
                                if (huizen[i - 1] == 0 && huizen[i + 1] == 0)
                                    {
                                        huizen2[i] = 0;
                                    }
                                if (huizen[i - 1] == 1 && huizen[i + 1] == 0)
                                    {
                                        huizen2[i] = 1;
                                    }
                                if (huizen[i - 1] == 0 && huizen[i + 1] == 1)
                                    {
                                        huizen2[i] = 1;
                                    }
                            }
                    }
                return huizen2;
            }

        // METHODE VOOR OMZETTING NAAR OO EN XX
        static string[] Omzetting(int[] huizen2)
            {
                string[] huizen3 = new string[20];

                for (int i = 0; i < huizen3.Length; i++)
                    {
                        if (huizen2[i] == 1)
                            {
                                huizen3[i] = "XX";                        
                            }
                        if (huizen2[i] == 0)
                            {
                                huizen3[i] = "00";                                           
                            }               
                    }
                return huizen3;
            }
    }
}
//benodigde tijd
//2h30
