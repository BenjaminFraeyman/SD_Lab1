﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo1_1
{
    class Persoon
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hallo vreemdeling");
            Console.WriteLine("Hoe heet je?"); // input
            string persoon = Console.ReadLine(); // string die je naam zal bevatten + ingave naam
            Console.WriteLine("HALLO {0}", persoon); // output
            Console.ReadLine();
        }
    }
}

// BENODIGDE TIJD
// 20 minuten (weer uitzoeken hoe alles zat nam redelijk wat tijd in beslag)