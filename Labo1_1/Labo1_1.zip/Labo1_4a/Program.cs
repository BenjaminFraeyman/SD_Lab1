﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo1_4a
{
    class Maximum
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Random random = new Random(); //random generator oproepen

                int getal = 0; //standaard grootste getal = 0
                Console.WriteLine(getal); //getal1 in console plaatsen

                Boolean groter = true; // indien nietgroter wordt dit false

                while (groter) //uitvoeren tot kleiner
                {
                    int getal2 = random.Next(0, 1000); //random getal2 maken, nummer 10 kan je aanpasses naar elk willekeurig getal

                    if (getal2 <= getal) // als getal2 niet groter is dan getal1 heb je je voorwaarde bekomen en ga je uit de while
                    {
                        Console.WriteLine(getal2);
                        groter = false; //hiermee sluit je de while af
                    }

                    if (getal2 > getal) //zolang getal2 groter is dan getal1 plaats je de waarde van getal2 in getal1
                    {
                        Console.WriteLine(getal2);
                        getal = getal2;
                    }
                }
                Console.ReadLine();
            }
        }
    }
}

// BENODIGDE TIJD
// 35 minuten
