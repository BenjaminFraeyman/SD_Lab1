﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo1_3b
{
    class HexenBin
    {       
        static void Main(string[] args)
        {
            Console.WriteLine("Getal?");
            int getal;
            getal = Convert.ToInt32(Console.ReadLine()); // input getal

            Console.WriteLine("Basis?");
            int basis;
            basis = Convert.ToInt32(Console.ReadLine());  //input basis

            string uitkomst;
            uitkomst = Omzetting(getal, basis); // verwijzing naar omzettings methode

            Console.WriteLine(uitkomst);
            Console.ReadLine();
        }

        static string Omzetting(int getal, int basis) //method om getal om te zetten
        {
            string tijdelijk = "";
            Boolean nietnul = true;
            string[] basiswaarde = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" }; //waarde van de basis
            while (nietnul) //uitvoeren tot je nul bekomt
            {
                tijdelijk = basiswaarde[getal % basis] + tijdelijk; // delen en rest terugsturen om zo omzetting naar andere basis te realiseren
                getal = getal / basis;

                if (getal == 0) // de omzetting is voltooid
                {
                    nietnul = false;
                }
            }
            return tijdelijk;
        }
    }
}

// BENODIGDE TIJD
// 25 minuten