﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo1_9_Sorteren
{
    class Sorteren
    {
        static void Main(string[] args)
        {
            // tussen welke waardes
            int Min = 0;
            int Max = 100;

            // hoeveel waardes
            int[] lijst = new int[20];

            //random generator oproepen en gebonden aan de tijd > iedere keer andere input
            Random random = new Random(DateTime.Now.Millisecond);

            // aanmaken van de lijst met willekeurige waardes
            for (int i = 0; i < lijst.Length; i++)
            {
                lijst[i] = random.Next(Min, Max);
            }

            // deze lijst in console plaatsen
            foreach (var item in lijst)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine(" ");

            // SORTEREN
            // je neemt eerste 2 waardes
            // als eerste > 2de dan wissel je deze van plaats
            // dit doe je terwijl je de array afloopt
            // daarna herhaal je dit
            // indien er geen wissels meer zijn is je lijst gesorteerd        

            for (int i = 0; i < Max; i++) // alle mogelijke waardes 
            {
                for (int j = 0; j < lijst.Length - 1; j++) // het sorteren van de waarde & -1 omdat je anders buiten array verplaatst
                {
                    if (lijst[j] > lijst[j + 1]) // check of de waarde groter is dan de volgende
                    {
                        int tijdelijk = 0; // integer om een waarde in op te slaan
                        tijdelijk = lijst[j + 1]; // verplaatsen 2de waarde naar tijdelijke opslag
                        lijst[j + 1] = lijst[j]; // 2de waarde krijgt de eerste waarde die groter is
                        lijst[j] = tijdelijk; // eerste waarde krijgt nu de waarde die in de tijdelijke opslag zat
                    }
                }
            }
            for (int i = 0; i < lijst.Length; i++) // uitschrijven gesorteerde lijst
                Console.Write(lijst[i] + " ");
            Console.ReadLine();
        }
    }
}
// BENODIGDE TIJD
// 2h